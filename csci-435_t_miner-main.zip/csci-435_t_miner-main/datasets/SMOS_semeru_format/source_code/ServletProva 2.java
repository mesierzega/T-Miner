package smos.application.teachingManagement;

import javax.servlet.http.HttpServlet;

public class ServletProva extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -832177625776300783L;

}
