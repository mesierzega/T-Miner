package smos.application.userManagement;

import javax.servlet.http.HttpServlet;

public class ServletShowUserTeachingFormByCourse extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2305151029867525356L;

}
