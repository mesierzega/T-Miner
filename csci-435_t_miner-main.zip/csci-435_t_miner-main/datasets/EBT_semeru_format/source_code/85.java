85	"Decompose Model public DecomposeModel(EBT em)
{
super( em);
MinimumNoRects = 3;
 }// Construct Visual model for Merge Event
public void BuildEvent()
{
 ClearVectors();
AddEventRect(20,20,1);
AddEventRect(60,70,1);
AddEventRect(60,120,1);
AddEventRect public StringBuffer GenerateEvent()
{
StringBuffer thisEvent = new StringBuffer();
StringBuffer temp = new StringBuffer();
int Count = -1;
thisEvent. append(""Decompose|"");

for ( int i = 0; i < EventShapes"
