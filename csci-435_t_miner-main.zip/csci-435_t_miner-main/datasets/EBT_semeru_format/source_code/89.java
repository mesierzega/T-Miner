89	"Event Line protected int top, left, right, bottom; public EventLine ( int t, int l, int r, int b)
{
top = t;
left = l;
right = r;
bottom = b;
} public int GetT() { return top;} public int GetL() { return left;}public int GetR() { return right;} public int GetB() { return bottom;}"
