93	"Obsolete Modelpublic ObsoleteModel(EBT em)
{
super( em);
 } // Construct Visual model for Merge Event
public void BuildEvent()
{
 ClearVectors();
AddEventRect(60,80,1);
AddLine(60,60,225,135);
AddLine(60,135,225,60);
CurrentEve public StringBuffer GenerateEvent()
 {
StringBuffer thisEvent = new StringBuffer();
thisEvent. append(""Obsolete|0|"");
thisEvent. append( new Date(). toString()+""|"");
ebs = (EBShape)EventShapes. e"
