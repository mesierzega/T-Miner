65	"About Dialog public AboutDialog(JFrame parent, boolean modal) {

 super ( parent, modal);
 
 getContentPane (). setLayout ( new BorderLayout ());
 setTitle (""About"");
 setName ("" aboutDialog"");
 
 private JTextArea text;"
